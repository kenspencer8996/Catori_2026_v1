﻿using CatoriCity2025WPF.Objects.DragDrop;
using Newtonsoft.Json.Bson;
using System.Windows.Media.Media3D;
using System.Windows.Threading;

namespace CatoriCity2025WPF.Views.Controls.Robots
{
    /// <summary>
    /// Interaction logic for RobotControl.xaml
    /// </summary>
    public partial class RobotControl : UserControl, IDraggable
    {
        List<string> robotImagePaths = new List<string>();
        private readonly DispatcherTimer _animateRobotTimer;
        int rowindex = 0;
        public event EventHandler? MoveRobotComplete;
        public UIElement Visual => throw new NotImplementedException();

        public Point OriginalPosition => throw new NotImplementedException();

        public RobotControl()
        {
            InitializeComponent();
            _animateRobotTimer = new DispatcherTimer();
            _animateRobotTimer.Interval = TimeSpan.FromMilliseconds(250); // 20 Hz flicker
            _animateRobotTimer.Tick += _animateRobotTimer_Tick; ;
        }

        private void _animateRobotTimer_Tick(object? sender, EventArgs e)
        {
            string thisImage = robotImagePaths[rowindex];
            RobotControlImage.Source = UIUtility.GetImageControl(thisImage, 10, 5, 0).Source;

            rowindex++;
            if (rowindex >= robotImagePaths.Count - 1)
            {
                rowindex = 0;
                _animateRobotTimer.Stop();
            }
        }

        public void AddRobotImage(string robotImage)
        {

            string thisimage = System.IO.Path.Combine(GlobalAllApps.ImageFolder, "Factories\\RobotArms", robotImage);
            robotImagePaths.Add(thisimage);
        }
        public void BuildProduct()
        {
            if (this.Visibility != Visibility.Visible)
            {
                this.Visibility = Visibility.Visible;
            }
            _animateRobotTimer.Start();
        }

        public void OnDropped()
        {
            //todo: add code to handle when the robot is dropped onto a factory
            if (MoveRobotComplete != null)
            {
                MoveRobotComplete.Invoke(this, EventArgs.Empty);
            }
        }
    }
}

